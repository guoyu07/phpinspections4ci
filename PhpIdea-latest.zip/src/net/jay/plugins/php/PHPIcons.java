package net.jay.plugins.php;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 22.02.2007
 *
 * @author jay
 */
public interface PHPIcons {
	final String PATH = "/net/jay/plugins/php/";

	final Icon PHP_ICON = IconLoader.findIcon(PATH + "php.png");

}
