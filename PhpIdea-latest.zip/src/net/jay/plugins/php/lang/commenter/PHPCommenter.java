package net.jay.plugins.php.lang.commenter;

import com.intellij.lang.Commenter;
import org.jetbrains.annotations.Nullable;

/**
 * @author jay
 * @time 21.12.2007 18:41:02
 */
public class PHPCommenter implements Commenter {
	@Nullable
	public String getLineCommentPrefix() {
		return "//";
	}

	@Nullable
	public String getBlockCommentPrefix() {
		return "/*";
	}

	@Nullable
	public String getBlockCommentSuffix() {
		return "*/";
	}
}
