package net.jay.plugins.php.lang;

import com.intellij.lang.Language;
import com.intellij.lang.ParserDefinition;
import com.intellij.lang.PairedBraceMatcher;
import com.intellij.lang.Commenter;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import net.jay.plugins.php.lang.highlighter.PHPSyntaxHighlighter;
import net.jay.plugins.php.lang.parser.PHPParserDefinition;
import net.jay.plugins.php.lang.braceMatcher.PHPBraceMatcher;
import net.jay.plugins.php.lang.commenter.PHPCommenter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 22.02.2007
 *
 * @author jay
 */
public class PHPLanguage extends Language {
	private PHPParserDefinition phpParserDefinition;
	private PHPSyntaxHighlighter phpSyntaxHighlighter;
	private PHPCommenter phpCommenter;
	private PHPBraceMatcher phpBraceMatcher;

	public PHPLanguage() {
		super(PHPFileType.NAME);
	}

	@Nullable
	public ParserDefinition getParserDefinition() {
		if (phpParserDefinition == null)
			phpParserDefinition = new PHPParserDefinition();
		return phpParserDefinition;
	}

	@NotNull
	public SyntaxHighlighter getSyntaxHighlighter(Project project, final VirtualFile virtualFile) {
		if (phpSyntaxHighlighter == null)
			phpSyntaxHighlighter = new PHPSyntaxHighlighter();
		return phpSyntaxHighlighter;
	}

	@Nullable
	public Commenter getCommenter() {
		if (phpCommenter == null)
			phpCommenter = new PHPCommenter();
		return phpCommenter;
	}

	@Nullable
	public PairedBraceMatcher getPairedBraceMatcher() {
		if (phpBraceMatcher == null)
			phpBraceMatcher = new PHPBraceMatcher();
		return phpBraceMatcher;
	}
}
