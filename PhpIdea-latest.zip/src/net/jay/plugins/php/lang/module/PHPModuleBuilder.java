package net.jay.plugins.php.lang.module;

import com.intellij.ide.util.projectWizard.ModuleBuilder;
import com.intellij.openapi.roots.ModifiableRootModel;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.module.ModuleType;

/**
 * @author jay
 * @time 21.12.2007 19:22:03
 */
public class PHPModuleBuilder extends ModuleBuilder {
	public void setupRootModel(ModifiableRootModel modifiableRootModel) throws ConfigurationException {
	}

	public ModuleType getModuleType() {
		return null;
	}
}
