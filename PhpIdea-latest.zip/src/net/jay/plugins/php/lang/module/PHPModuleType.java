package net.jay.plugins.php.lang.module;

import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.module.ModuleType;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * @author jay
 * @time 21.12.2007 19:19:17
 */
public class PHPModuleType extends ModuleType<PHPModuleBuilder> implements ApplicationComponent {
	private static final String PHP_MODULE = "PHP_MODULE";

	public PHPModuleType() {
		super(PHP_MODULE);
	}

	public void initComponent() {
		// TODO: insert component initialization logic here
	}

	public void disposeComponent() {
		// TODO: insert component disposal logic here
	}

	@NotNull
	public String getComponentName() {
		return "PHPModuleType";
	}

	public PHPModuleBuilder createModuleBuilder() {
		return new PHPModuleBuilder();
	}

	public String getName() {
		return "PHP Module";
	}

	public String getDescription() {
		return "Makes PHP development easier.";
	}

	public Icon getBigIcon() {
		return null;
	}

	public Icon getNodeIcon(boolean isOpened) {
		return null;
	}
}
