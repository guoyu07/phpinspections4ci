package net.jay.plugins.php.lang.psi.elements.impl;

import net.jay.plugins.php.lang.psi.elements.PHPCode;
import com.intellij.lang.ASTNode;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 30.03.2007
 *
 * @author jay
 */
public class PHPCodeImpl extends PHPPsiElementImpl implements PHPCode {

	public PHPCodeImpl(ASTNode node) {
		super(node);
	}
}
