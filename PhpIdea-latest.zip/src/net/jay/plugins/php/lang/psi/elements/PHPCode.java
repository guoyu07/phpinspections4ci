package net.jay.plugins.php.lang.psi.elements;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 30.03.2007
 *
 * @author jay
 */
public interface PHPCode extends PHPPsiElement {

}
