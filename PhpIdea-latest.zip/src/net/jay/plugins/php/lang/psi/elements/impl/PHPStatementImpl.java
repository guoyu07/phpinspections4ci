package net.jay.plugins.php.lang.psi.elements.impl;

import net.jay.plugins.php.lang.psi.elements.PHPStatement;
import com.intellij.lang.ASTNode;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 30.03.2007
 *
 * @author jay
 */
public class PHPStatementImpl extends PHPPsiElementImpl implements PHPStatement {

	public PHPStatementImpl(ASTNode node) {
		super(node);
	}
}
