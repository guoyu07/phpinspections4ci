package net.jay.plugins.php.lang.psi.elements.impl;

import com.intellij.extapi.psi.ASTWrapperPsiElement;
import com.intellij.lang.ASTNode;
import com.intellij.lang.Language;
import net.jay.plugins.php.lang.psi.elements.PHPPsiElement;
import net.jay.plugins.php.lang.PHPFileType;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 13.03.2007
 *
 * @author jay
 */
public class PHPPsiElementImpl extends ASTWrapperPsiElement implements PHPPsiElement {

	public PHPPsiElementImpl(ASTNode node) {
		super(node);
	}

	public String toString() {
		return getNode().getElementType().toString();
	}

	@NotNull
	public Language getLanguage() {
		return PHPFileType.PHP.getLanguage();
	}
}
