package net.jay.plugins.php.lang.psi;

import com.intellij.psi.PsiFile;
import com.intellij.psi.FileViewProvider;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.extapi.psi.PsiFileBase;
import com.intellij.openapi.fileTypes.FileType;
import net.jay.plugins.php.lang.PHPFileType;
import net.jay.plugins.php.lang.psi.visitors.PHPElementVisitor;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 26.02.2007
 *
 * @author jay
 */
public class PHPFile extends PsiFileBase implements PsiFile {

	public PHPFile(FileViewProvider viewProvider) {
		super(viewProvider, PHPFileType.PHP.getLanguage());
	}

	@NotNull
	public FileType getFileType() {
		return PHPFileType.PHP;
	}

	public String toString() {
		return "PHP file";
	}

	public void accept(PsiElementVisitor visitor) {
		if (visitor instanceof PHPElementVisitor) {
			((PHPElementVisitor) visitor).visitPHPFile(this);
		} else {
			super.accept(visitor);
		}
	}
}
