package net.jay.plugins.php.lang.psi.elements;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 02.04.2007
 *
 * @author jay
 */
public interface PHPCondition extends PHPPsiElement {

}
