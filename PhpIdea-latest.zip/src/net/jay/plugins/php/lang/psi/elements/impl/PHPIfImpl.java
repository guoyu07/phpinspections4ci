package net.jay.plugins.php.lang.psi.elements.impl;

import net.jay.plugins.php.lang.psi.elements.PHPIf;
import net.jay.plugins.php.lang.psi.elements.PHPCondition;
import com.intellij.lang.ASTNode;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 02.04.2007
 *
 * @author jay
 */
public class PHPIfImpl extends PHPPsiElementImpl implements PHPIf {

	public PHPIfImpl(ASTNode node) {
		super(node);
	}

	public PHPCondition getCondition() {
		return null;
	}
}
