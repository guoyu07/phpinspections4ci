package net.jay.plugins.php.lang.psi.visitors;

import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiReferenceExpression;
import com.intellij.psi.PsiElement;
import net.jay.plugins.php.lang.psi.PHPFile;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 27.02.2007
 *
 * @author jay
 */
public abstract class PHPElementVisitor extends PsiElementVisitor {

	public void visitReferenceExpression(PsiReferenceExpression expression) {
		visitElement(expression);
	}


	public void visitElement(PsiElement element) {
		
	}

	public void visitPHPFile(PHPFile phpFile) {
		visitElement(phpFile);
	}
}
