package net.jay.plugins.php.lang.psi.elements.impl;

import net.jay.plugins.php.lang.psi.elements.PHPCondition;
import com.intellij.lang.ASTNode;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 02.04.2007
 *
 * @author jay
 */
public class PHPConditionImpl extends PHPPsiElementImpl implements PHPCondition {

	public PHPConditionImpl(ASTNode node) {
		super(node);
	}
}
