package net.jay.plugins.php.lang.parser;

import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.IFileElementType;
import com.intellij.lang.Language;
import net.jay.plugins.php.lang.psi.PHPElementType;
import net.jay.plugins.php.lang.PHPLanguage;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 26.02.2007
 *
 * @author jay
 */
public interface PHPElementTypes {

	final IFileElementType FILE = new IFileElementType(Language.findInstance(PHPLanguage.class));
	IElementType EMPTY_INPUT = new PHPElementType("Unrecognised input");
	IElementType DUMMY = new PHPElementType("DUMMY");

	IElementType HTML_CODE = new PHPElementType("HTML code");
	IElementType CODE = new PHPElementType("Code");
	IElementType ECHO_CODE = new PHPElementType("Echo code");
	IElementType HTML = new PHPElementType("HTML");

	IElementType CLASS = new PHPElementType("Class");
	IElementType FIELD = new PHPElementType("Field");
	IElementType FUNCTION = new PHPElementType("Function");
	IElementType PARAMETER_LIST = new PHPElementType("Parameter list");
	IElementType PARAMETER = new PHPElementType("Parameter");

	IElementType STATEMENT = new PHPElementType("Statement");
	IElementType IF = new PHPElementType("If");
	IElementType CONDITION = new PHPElementType("Condition");
	IElementType GROUP_STATEMENT = new PHPElementType("Group statement");
	IElementType UNARY_EXPRESSION = new PHPElementType("Unary expression");
	IElementType VARIABLE_REFERENCE = new PHPElementType("Variable reference");
	IElementType INTEGER = new PHPElementType("Integer");
	IElementType FLOAT = new PHPElementType("Float");
	IElementType STRING = new PHPElementType("String");
	IElementType BINARY_OPERATION = new PHPElementType("Binary operation");
	IElementType CONSTANT = new PHPElementType("Constant");
	IElementType CLASS_REFERENCE = new PHPElementType("Class reference");
	IElementType FUNCTION_REFERENCE = new PHPElementType("Function reference");
	IElementType USER_CONSTANT = new PHPElementType("Constant");
	IElementType VARIABLE = new PHPElementType("Variable");
	IElementType ASSIGNMENT_EXPRESSION = new PHPElementType("Assignment expression");
	IElementType SELF_ASSIGNMENT_EXPRESSION = new PHPElementType("Self assignment expression");
	IElementType GROUP_EXPRESSION = new PHPElementType("Expression group");
	IElementType ARRAY_INDEX = new PHPElementType("Array index");
	IElementType ARRAY_REFERENCE = new PHPElementType("Array reference");
	IElementType OBSCURE_ARRAY_REFERENCE = new PHPElementType("Obscure array reference");
	IElementType OBSCURE_VARIABLE_REFERENCE = new PHPElementType("Obscure variable reference");
	IElementType OBSCURE_FUNCTION_REFERENCE = new PHPElementType("Obscure function reference");
	IElementType OBSCURE_CLASS_REFERENCE = new PHPElementType("Obscure class reference");
	IElementType CLASS_CONSTANT_REFERENCE = new PHPElementType("Class constant reference");
	IElementType ELSE_IF = new PHPElementType("Elseif");
	IElementType ELSE = new PHPElementType("Else");
	IElementType TERNARY_EXPRESSION = new PHPElementType("Ternary expression");
	IElementType TERNARY_FALSE_BRANCH = new PHPElementType("False branch");
	IElementType TERNARY_TRUE_BRANCH = new PHPElementType("True branch");
	IElementType CLASS_INSTANTIATION = new PHPElementType("Class instantiation");
	IElementType INSTANCEOF_EXPRESSION = new PHPElementType("Instanceof expression");
	IElementType ARRAY_INDEX_AUTOINCREMENT = new PHPElementType("Array index autoincrement");
	IElementType PRINT_EXPRESSION = new PHPElementType("Print expression");
	IElementType ARRAY = new PHPElementType("Array");
	IElementType ARRAY_KEY = new PHPElementType("Array key");
	IElementType ARRAY_VALUE = new PHPElementType("Array value");
	IElementType EMPTY_CONSTRUCT = new PHPElementType("Empty");
	IElementType EXIT_EXPRESSION = new PHPElementType("Exit expression");
	IElementType ISSET_EXPRESSION = new PHPElementType("Isset function");
	IElementType FOR = new PHPElementType("For");
	IElementType FOR_INITIAL = new PHPElementType("Initial expression");
	IElementType FOR_CONDITION = new PHPElementType("Conditional expression");
	IElementType FOR_REPEATED = new PHPElementType("Repeated expression");
	IElementType FOREACH = new PHPElementType("Foreach");
	IElementType FOREACH_KEY = new PHPElementType("Key");
	IElementType FOREACH_VALUE = new PHPElementType("Value");
	IElementType WHILE = new PHPElementType("While");
	IElementType DO_WHILE = new PHPElementType("Do while");
	IElementType BREAK = new PHPElementType("Break");
	IElementType CONTINUE = new PHPElementType("Continue");
	IElementType ECHO = new PHPElementType("Echo");
	IElementType GLOBAL = new PHPElementType("Global");
	IElementType TYPE_HINT = new PHPElementType("Type hint");
	IElementType FUNCTION_BODY = new PHPElementType("Body");
	IElementType UNSET = new PHPElementType("Unset");



	IElementType IS_REFERENCE = new PHPElementType("Is reference");
	IElementType PARAMETER_DEFAULT_VALUE = new PHPElementType("Parameter default value");
	IElementType COMMON_SCALAR = new PHPElementType("Common scalar");
	IElementType STATIC_SCALAR = new PHPElementType("Static scalar");
	IElementType EXTENDS_LIST = new PHPElementType("Extends list");
	IElementType INTERFACE = new PHPElementType("Interface");
	IElementType IMPLEMENTS_LIST = new PHPElementType("Implements list");
	IElementType FINAL_CLASS = new PHPElementType("Final class");
	IElementType ABSTRACT_CLASS = new PHPElementType("Abstract class");
	IElementType CLASS_CONSTANT = new PHPElementType("Class constant");
	IElementType MODIFIER_LIST = new PHPElementType("Modifier list");
	IElementType CLASS_FIELD = new PHPElementType("Class field");
	IElementType CLASS_FIELDS = new PHPElementType("Class fields");
	IElementType CLASS_METHOD = new PHPElementType("Class method");
	IElementType CLASS_ABSTRACT_METHOD = new PHPElementType("Class abstract method");
	IElementType SWITCH = new PHPElementType("Switch statement");
	IElementType CASE_DEFAULT = new PHPElementType("Default case");
	IElementType CASE = new PHPElementType("Case");
	IElementType RETURN = new PHPElementType("Return");
	IElementType STATIC = new PHPElementType("Static statement");
	IElementType DECLARE = new PHPElementType("Declare statement");
	IElementType DECLARE_DIRECTIVE = new PHPElementType("Declare directive");
	IElementType TRY = new PHPElementType("Try statement");
	IElementType CATCH = new PHPElementType("Catch clause");
	IElementType THROW = new PHPElementType("Throw statement");
	IElementType EXPRESSION = new PHPElementType("Expression");
	IElementType OBSCURE_VARIABLE = new PHPElementType("Obscure variable");
	IElementType FUNCTION_CALL = new PHPElementType("Function call");
	IElementType OBJECT_PROPERTY = new PHPElementType("Object property");
	IElementType LITERAL_LOGICAL_EXPRESSION = new PHPElementType("Literal logical expression");
	IElementType LOGICAL_EXPRESSION = new PHPElementType("Logical expression");
	IElementType BIT_EXPRESSION = new PHPElementType("Bint expression");
	IElementType EQUALITY_EXPRESSION = new PHPElementType("Equality expression");
	IElementType RELATIONAL_EXPRESSION = new PHPElementType("Relational expression");
	IElementType SHIFT_EXPRESSION = new PHPElementType("Shift expression");
	IElementType ADDITIVE_EXPRESSION = new PHPElementType("Additive expression");
	IElementType MULTIPLICATIVE_EXPRESSION = new PHPElementType("Multiplicative expression");
	IElementType CAST_EXPRESSION = new PHPElementType("Cast expression");
	IElementType SILENCE_EXPRESSION = new PHPElementType("Silence expression");
	IElementType POSTFIX_EXPRESSION = new PHPElementType("Postfix expression");
	IElementType HEREDOC = new PHPElementType("Heredoc");
	IElementType VARIABLE_NAME = new PHPElementType("Variable name");
	IElementType NUMBER = new PHPElementType("Number");
	IElementType SHELL_COMMAND = new PHPElementType("Shell command");
	IElementType NEW_EXPRESSION = new PHPElementType("New expression");
	IElementType INCLUDE_EXPRESSION = new PHPElementType("Include expression");
	IElementType EMPTY_EXPRESSION = new PHPElementType("Empty expression");
	IElementType EVAL_EXPRESSION = new PHPElementType("Eval expression");
	IElementType CLONE_EXPRESSION = new PHPElementType("Clone expression");
	IElementType MULTIASSIGNMENT_EXPRESSION = new PHPElementType("Multiassignment expression");
}
