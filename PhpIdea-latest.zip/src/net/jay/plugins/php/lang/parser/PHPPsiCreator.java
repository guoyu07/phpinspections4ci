package net.jay.plugins.php.lang.parser;

import com.intellij.lang.ASTNode;
import com.intellij.psi.PsiElement;
import com.intellij.psi.tree.IElementType;
import net.jay.plugins.php.lang.psi.elements.impl.PHPPsiElementImpl;
import net.jay.plugins.php.lang.psi.elements.impl.PHPCodeImpl;
import net.jay.plugins.php.lang.psi.elements.impl.PHPStatementImpl;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 30.03.2007
 *
 * @author jay
 */
public class PHPPsiCreator implements PHPElementTypes {

	public static PsiElement create(ASTNode node) {
		IElementType type = node.getElementType();
		if (type == CODE) {
			return new PHPCodeImpl(node);
		}
		if (type == STATEMENT) {
			return new PHPStatementImpl(node);
		}
		return new PHPPsiElementImpl(node);
	}
}
