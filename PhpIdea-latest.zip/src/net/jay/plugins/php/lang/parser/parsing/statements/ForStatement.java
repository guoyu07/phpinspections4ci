package net.jay.plugins.php.lang.parser.parsing.statements;

import com.intellij.lang.PsiBuilder;
import com.intellij.psi.tree.IElementType;
import net.jay.plugins.php.lang.lexer.PHPTokenTypes;
import net.jay.plugins.php.lang.parser.PHPElementTypes;
import net.jay.plugins.php.lang.parser.parsing.Statement;
import net.jay.plugins.php.lang.parser.parsing.StatementList;
import net.jay.plugins.php.lang.parser.parsing.expressions.Expression;
import net.jay.plugins.php.lang.parser.util.ListParsingHelper;
import net.jay.plugins.php.lang.parser.util.PHPPsiBuilder;
import net.jay.plugins.php.lang.parser.util.ParserPart;

/**
 * Created by IntelliJ IDEA.
 * User: markov
 * Date: 01.11.2007
 */
public class ForStatement implements PHPTokenTypes {

	//	kwFOR '('
	//		for_expr ';'
	//		for_expr ';'
	//		for_expr ')' for_statement
	public static IElementType parse(PHPPsiBuilder builder) {
		PsiBuilder.Marker statement = builder.mark();
		if (!builder.compareAndEat(kwFOR)) {
			statement.drop();
			return PHPElementTypes.FOR;
		}
		builder.match(chLPAREN);

		PsiBuilder.Marker initialExpr = builder.mark();
		parseForExpression(builder);
		initialExpr.done(PHPElementTypes.FOR_INITIAL);

		builder.match(opSEMICOLON);

		PsiBuilder.Marker conditionalExpr = builder.mark();
		parseForExpression(builder);
		conditionalExpr.done(PHPElementTypes.FOR_CONDITION);

		builder.match(opSEMICOLON);

		PsiBuilder.Marker repeatedExpr = builder.mark();
		parseForExpression(builder);
		repeatedExpr.done(PHPElementTypes.FOR_REPEATED);

		builder.match(chRPAREN);
		parseForStatement(builder);
		statement.done(PHPElementTypes.FOR);
		return PHPElementTypes.FOR;
	}

	//	for_statement:
	//		statement
	//		| ':' statement_list kwENDFOR ';'
	//	;
	private static void parseForStatement(PHPPsiBuilder builder) {
		if (builder.compareAndEat(opCOLON)) {
			StatementList.parse(builder, kwENDFOR);
			builder.match(kwENDFOR);
			builder.match(opSEMICOLON);
		} else {
			Statement.parse(builder);
		}
	}

	//	for_expr:
	//		/* empty */
	//		| non_empty_for_expr
	//	;
	//
	//	non_empty_for_expr:
	//		non_empty_for_expr ',' expr
	//		| expr
	//	;
	private static void parseForExpression(PHPPsiBuilder builder) {
		ParserPart parserPart = new ParserPart() {
			public IElementType parse(PHPPsiBuilder builder) {
				return Expression.parse(builder);
			}
		};
		ListParsingHelper.parseCommaDelimitedExpressionWithLeadExpr(
			builder,
			parserPart.parse(builder),
			parserPart,
			false
		);
	}
}
