package net.jay.plugins.php.lang.parser;

import com.intellij.lang.ASTNode;
import com.intellij.lang.PsiBuilder;
import com.intellij.lang.PsiParser;
import com.intellij.psi.tree.IElementType;
import net.jay.plugins.php.lang.parser.parsing.Program;
import net.jay.plugins.php.lang.parser.util.PHPPsiBuilder;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: jay
 * Date: 26.02.2007
 *
 * @author jay
 */
public class PHPPsiParser implements PsiParser {

	@NotNull
	public ASTNode parse(IElementType root, PsiBuilder builder) {
//		builder.setDebugMode(true);
		PHPPsiBuilder psiBuilder = new PHPPsiBuilder(builder);

		PsiBuilder.Marker marker = psiBuilder.mark();
		Program.parse(psiBuilder);
		marker.done(root);
		return psiBuilder.getTreeBuilt();
	}
}
