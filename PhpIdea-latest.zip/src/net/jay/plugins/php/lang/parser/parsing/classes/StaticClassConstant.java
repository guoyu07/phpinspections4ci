package net.jay.plugins.php.lang.parser.parsing.classes;

import com.intellij.psi.tree.IElementType;
import com.intellij.lang.PsiBuilder;
import net.jay.plugins.php.lang.lexer.PHPTokenTypes;
import net.jay.plugins.php.lang.parser.PHPElementTypes;
import net.jay.plugins.php.lang.parser.util.PHPPsiBuilder;

/**
 * @author markov
 * @date 17.10.2007
 */
public class StaticClassConstant implements PHPTokenTypes {

	//	static_class_constant:
	//		IDENTIFIER SCOPE_RESOLUTION IDENTIFIER
	//	;
	public static IElementType parse(PHPPsiBuilder builder) {
		if (!builder.compare(IDENTIFIER)) {
			return PHPElementTypes.EMPTY_INPUT;
		}
		PsiBuilder.Marker classConstantReference = builder.mark();
		ClassReference.parse(builder);
		if (!builder.compareAndEat(SCOPE_RESOLUTION)) {
			classConstantReference.rollbackTo();
			return PHPElementTypes.EMPTY_INPUT;
		}
		builder.match(IDENTIFIER);
		classConstantReference.done(PHPElementTypes.CLASS_CONSTANT_REFERENCE);
		return PHPElementTypes.CLASS_CONSTANT_REFERENCE;
	}
}
